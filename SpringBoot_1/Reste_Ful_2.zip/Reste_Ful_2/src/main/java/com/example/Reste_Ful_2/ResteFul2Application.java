package com.example.Reste_Ful_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResteFul2Application {

	public static void main(String[] args) {
		SpringApplication.run(ResteFul2Application.class, args);
	}

}
