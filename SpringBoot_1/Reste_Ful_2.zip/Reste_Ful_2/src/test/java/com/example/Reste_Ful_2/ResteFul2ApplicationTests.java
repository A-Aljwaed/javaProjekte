package com.example.Reste_Ful_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResteFul2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
